//
//  Hostname.h
//  SafariCookie
//
//  Created by 卢祥庭 on 9/8/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Hostname : NSObject

+ (NSString *)hostname;

@end
