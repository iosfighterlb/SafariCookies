//
//  Hostname.m
//  SafariCookie
//
//  Created by 卢祥庭 on 9/8/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "Hostname.h"

@implementation Hostname

+ (NSString*) hostname
{
    NSString *hostFilePath = [[NSBundle mainBundle] pathForResource:@"host" ofType:@"txt"];
    
    NSError *error = nil;
    NSString *hostUrl = [NSString stringWithContentsOfFile:hostFilePath encoding:NSUTF8StringEncoding error:&error];

    NSString *apiBaseUrl = [NSString stringWithFormat:@"http://%@", hostUrl];
    if (error || !apiBaseUrl)
    {
        NSLog(@"Could not find host file.");
    }
    
    NSLog(@"apiBaseUrl : %@", apiBaseUrl);
    
    return apiBaseUrl;
}

@end
