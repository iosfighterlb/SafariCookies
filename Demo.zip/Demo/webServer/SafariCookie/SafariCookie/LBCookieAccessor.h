//
//  LBCookieAccessor.h
//  SafariCookie
//
//  Created by 卢祥庭 on 9/9/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

@import SafariServices;
@import UIKit;

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const LBCookieAccessorDidGetCookieNotification;

typedef void(^LBCookieAccessorCompletion)(NSString *code);

@interface LBCookieAccessor : NSObject  <SFSafariViewControllerDelegate>

- (void) fetchStoredCookiesWithViewController:(UIViewController*)viewController cookiekey:(NSString *)cookiekey
                                   completion:(LBCookieAccessorCompletion)completion;

- (void) storedCookiesWithViewController:(UIViewController*)viewController key:(NSString *)key value:(NSString *)value
                              completion:(LBCookieAccessorCompletion)completion;

+ (BOOL) handleOpenUrl:(NSURL*)url;

@end
