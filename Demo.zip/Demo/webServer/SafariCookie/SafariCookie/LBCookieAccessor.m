//
//  LBCookieAccessor.m
//  SafariCookie
//
//  Created by 卢祥庭 on 9/9/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "LBCookieAccessor.h"
#import "Hostname.h"

//Notifications
NSString *const LBCookieAccessorDidGetCookieNotification = @"LBCookieAccessorDidGetCookieNotification";

//Constants
static NSString *const kLBCookieAccessorCodeKey = @"code";
static NSString *const kLBCookieStoreHtml = @"cookieIndex.html";
static NSString *const kLBCookieAccessorHtml = @"cookieManager.html";


@interface LBCookieAccessor ()

@property (nonatomic, copy) LBCookieAccessorCompletion completion;
@property (nonatomic, strong) SFSafariViewController *safari;

@end


@implementation LBCookieAccessor

- (void)fetchStoredCookiesWithViewController:(UIViewController *)viewController cookiekey:(NSString *)cookiekey
                                                                completion:(LBCookieAccessorCompletion)completion
{
    if (self.safari) self.safari = nil;

    self.completion = completion;
    
    // 这里是在这里host里面（可以用Mac 自带的apache自己做一个服务器）
    // 放置这个Html文件.
    // 这个html做的就是从cookie获取信息
    
    NSString *host = [Hostname hostname];
    NSString *urlString = [NSString stringWithFormat:@"%@:8888/%@?%@", host, kLBCookieAccessorHtml, cookiekey];
    NSLog(@"fetch store key : %@", urlString);

    NSURL *url = [NSURL URLWithString:urlString];
    
    [self observeCookieNotification];

    self.safari = [[SFSafariViewController alloc] initWithURL:url];
    self.safari.delegate = self;
    self.safari.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    self.safari.view.userInteractionEnabled = NO;
    self.safari.view.layer.opacity = 0.0F;
    self.safari.view.frame = CGRectZero;
    [viewController presentViewController:self.safari animated:NO completion:^{ }];
}




// JS脚本需要添加多一个，获取 '=' 前后
- (void)storedCookiesWithViewController:(UIViewController *)viewController key:(NSString *)key value:(NSString *)value
                             completion:(LBCookieAccessorCompletion)completion
{
    if (self.safari) self.safari = nil;
    
    self.completion = completion;
    
    NSString *host = [Hostname hostname];
    NSString *urlString = [NSString stringWithFormat:@"%@:8888/%@?%@=%@", host, kLBCookieStoreHtml, key, value];
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    [self observeCookieNotification];
    
    self.safari = [[SFSafariViewController alloc] initWithURL:url];
    self.safari.delegate = self;
    self.safari.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    self.safari.view.userInteractionEnabled = NO;
    self.safari.view.layer.opacity = 0.0F;
    self.safari.view.frame = CGRectZero;
    [viewController presentViewController:self.safari animated:NO completion:^{ }];
}


#pragma mark - 跳转回调.

+ (BOOL) handleOpenUrl:(NSURL*)url
{
    NSString *urlString = [url absoluteString];
    NSLog(@"handOpenUrl :%@", urlString);

    NSString *code = [self codeFromUrl:url];
    NSDictionary *userInfo = code ? @{kLBCookieAccessorCodeKey : code} : nil;
    [[NSNotificationCenter defaultCenter] postNotificationName:LBCookieAccessorDidGetCookieNotification
                                                        object:url userInfo:userInfo];
    return YES;
}



#pragma mark - Private

- (void) dismissSafariWithCode:(NSString*)code
{
    __weak typeof(self) weakSelf = self;
    [self.safari dismissViewControllerAnimated:NO completion:^{
        if (weakSelf.completion) { weakSelf.completion(code); }
    }];
}



// http://nshipster.cn/nsurl/
+ (NSString*) codeFromUrl:(NSURL*)url
{
    NSURLComponents *components = [NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];
    NSArray <NSURLQueryItem*>*queryItems = components.queryItems;
    
    NSLog(@"NSURLComponents : %@", queryItems);
    
    
    for (NSURLQueryItem *queryItem in queryItems)
    {
        if ([queryItem.name isEqualToString:kLBCookieAccessorCodeKey])
        {
            return queryItem.value;
        }
    }
    
    return nil;
}


#pragma mark - 获取code.

+ (NSString*) codeFromNotification:(NSNotification*)notification
{
    if ([notification.name isEqualToString:LBCookieAccessorDidGetCookieNotification] == NO) return nil;
    NSDictionary *userInfo = notification.userInfo;
    if (!userInfo) return nil;
    
    id code = userInfo[kLBCookieAccessorCodeKey];
    if (!code || [code isKindOfClass:[NSString class]] == NO) return nil;
    
    return code;
}


#pragma mark - 让获取Cookie添加通知.

// http://www.jianshu.com/p/5848b6604033
// http://www.tuicool.com/articles/MNjamm
- (void) observeCookieNotification {
    __weak NSNotificationCenter *noteCenter = [NSNotificationCenter defaultCenter];
    __weak typeof(self) weakSelf = self;
    __block __weak id<NSObject> observer = [noteCenter addObserverForName:LBCookieAccessorDidGetCookieNotification object:nil queue:nil
                                                               usingBlock:^(NSNotification * _Nonnull note) {
                                                                   NSString *code = [LBCookieAccessor codeFromNotification:note];
                                                                   [weakSelf dismissSafariWithCode:code];
                                                                   [noteCenter removeObserver:observer];       // 自释放.
                                                              
                                                               }];
}

@end











