//
//  ViewController.m
//  SafariCookie
//
//  Created by 卢祥庭 on 9/8/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "Hostname.h"
#import "ViewController.h"
#import "LBCookieAccessor.h"

@interface ViewController ()

@property (strong, nonatomic) LBCookieAccessor *cookieAccessor;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.cookieAccessor = [[LBCookieAccessor alloc] init];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


#pragma mark - Actions

- (IBAction) tappedActionButton:(id)sender
{
    [self accessCookie];
}


- (IBAction) tappedCreateCodeButton:(id)sender
{
    [self storeCookie];
}


#pragma mark - Private

- (void) storeCookie
{
    NSString *title = @"Enter what you want to store";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    // alert的样式从以往的方式成这样block的回调形式.
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Enter cookie key";
    }];
    
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Enter cookie value";
    }];
    
    
    // 这里block 中 嵌套block，循环引用该怎么处理.
    // https://www.zhihu.com/question/30779258
    NSString *buttonTitle = @"OK";
    __weak typeof(self) weakSelf = self;
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * _Nonnull action) {
                                                         
                                                         UITextField *textField1 = [[alert textFields] objectAtIndex:0];
                                                         UITextField *textField2 = [[alert textFields] objectAtIndex:1];

                                                         [self.cookieAccessor storedCookiesWithViewController:self key:textField1.text value:textField2.text completion:^(NSString *code){ }];
                                                         
                                                     }];
    [alert addAction:okAction];
    buttonTitle = @"Cancle";
    okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleCancel
                                      handler:^(UIAlertAction * _Nonnull action) {}];
    [alert addAction:okAction];
    
    [self presentViewController:alert animated:YES completion:^{}];
}




- (void) accessCookie
{
    NSString *title = @"Enter what you want to know";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    // alert的样式从以往的方式成这样block的回调形式.
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Enter cookie key";
    }];
    
    
    // 这里block 中 嵌套block，循环引用该怎么处理.
    // https://www.zhihu.com/question/30779258
    NSString *buttonTitle = @"OK";
    __weak typeof(self) weakSelf = self;
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * _Nonnull action) {
                                      
                                      UITextField *textField = [[alert textFields] objectAtIndex:0];
                                      [self.cookieAccessor fetchStoredCookiesWithViewController:self cookiekey:textField.text
                                                           completion:^(NSString *code){
                                                               [weakSelf showSuccessWithCode:code];
                                                           }];
                                      
                                  }];
    [alert addAction:okAction];
    buttonTitle = @"Cancle";
    okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleCancel
                                      handler:^(UIAlertAction * _Nonnull action) {}];
    [alert addAction:okAction];
    
    [self presentViewController:alert animated:YES completion:^{}];
}





- (void) showSuccessWithCode:(NSString*)code
{
    NSString *title = code ? @"Achieve a cookie !" : @"Error";
    NSString *message = code ? [NSString stringWithFormat:@"Code: %@", code] : @"Could not fetch cookie.";
    NSString *buttonTitle = code ? @"Nom Nom" : @"OK";
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];

    
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction * _Nonnull action) {}];
    [alert addAction:okAction];
    
    [self presentViewController:alert animated:YES completion:^{}];
}

@end
